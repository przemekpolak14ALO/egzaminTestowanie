package com.example.egzamin1;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Kosc[] kosci = new Kosc[5];
    private ImageView[] imageViews = new ImageView[5];
    private TextView textView;
    private int[] drawableIds = {
            R.drawable.kosc0,
            R.drawable.kosc1,
            R.drawable.kosc2,
            R.drawable.kosc3,
            R.drawable.kosc4,
            R.drawable.kosc5,
            R.drawable.kosc6
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imageViews[0] = findViewById(R.id.imageView);
        imageViews[1] = findViewById(R.id.imageView1);
        imageViews[2] = findViewById(R.id.imageView3);
        imageViews[3] = findViewById(R.id.imageView4);
        imageViews[4] = findViewById(R.id.imageView5);
        textView = findViewById(R.id.textView);
        Button btn = findViewById(R.id.button);

        for (int i = 0; i < 5; i++) {
            kosci[i] = new Kosc(0);
        }

        aktualizujWidok();

        btn.setOnClickListener(v -> {
            for (int i = 0; i < 5; i++) {
                kosci[i].rzuc();
            }
            aktualizujWidok();
        });

        for (int i = 0; i < 5; i++) {
            final int index = i;
            imageViews[i].setOnClickListener(v -> {
                if (kosci[index].czyDostepna) {
                    kosci[index].blokuj();
                } else {
                    kosci[index].czyDostepna = true;
                }
                aktualizujWidok();
            });
        }
    }

    private void aktualizujWidok() {
        int suma = 0;
        for (int i = 0; i < 5; i++) {
            suma += kosci[i].liczbaOczek;
            imageViews[i].setImageResource(drawableIds[kosci[i].idPliku]);

            if (kosci[i].czyDostepna) {
                imageViews[i].setAlpha(1.0f);
            } else {
                imageViews[i].setAlpha(0.5f);
            }
        }
        textView.setText(String.valueOf(suma));
    }
}