import java.util.Random;

public class Kosc {

    public static int licznikInstancji = 0;
    public String[] nazwyPlikow = {
            "kosc0.png", "kosc1.png", "kosc2.png", "kosc3.png",
            "kosc4.png", "kosc5.png", "kosc6.png"
    };
    public int liczbaOczek;
    public int idPliku;
    public boolean czyDostepna;
    public Kosc(int wartosc) {
        if (wartosc >= 1 && wartosc <= 6) {
            this.liczbaOczek = wartosc;
            this.idPliku = wartosc;
        } else {
            this.liczbaOczek = 0;
            this.idPliku = 0;
        }
        this.czyDostepna = true;
        licznikInstancji++;
    }
    public Kosc() {
        Random rand = new Random();
        int wylosowana = rand.nextInt(6) + 1;

        this.liczbaOczek = wylosowana;
        this.idPliku = wylosowana;
        this.czyDostepna = true;
        licznikInstancji++;
    }
    public void rzuc() {
        if (czyDostepna) {
            Random rand = new Random();
            int wylosowana = rand.nextInt(6) + 1;
            this.liczbaOczek = wylosowana;
            this.idPliku = wylosowana;
        }
    }
    public void blokuj() {
        this.czyDostepna = false;
    }

    public String dajSlownie() {
        switch (liczbaOczek) {
            case 1: return "jeden";
            case 2: return "dwa";
            case 3: return "trzy";
            case 4: return "cztery";
            case 5: return "pięć";
            case 6: return "sześć";
            default: return "błędna wartość / zero";
        }
    }

    public void wyswietlInformacje() {
        System.out.println("----------------------------------------");
        System.out.println("Liczba utworzonych instancji kości: " + licznikInstancji);
        System.out.println("Wyrzucone oczek (liczbowo): " + liczbaOczek);
        System.out.println("Wyrzucone oczek (słownie): " + dajSlownie());
        System.out.println("Odpowiedni plik graficzny: " + nazwyPlikow[idPliku]);
        System.out.println("Czy kość jest dostępna: " + (czyDostepna ? "Tak" : "Nie"));
        System.out.println("----------------------------------------");
    }
}