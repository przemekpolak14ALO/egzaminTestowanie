import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== TWORZENIE PIERWSZEJ KOŚCI (Konstruktor bezargumentowy - losowanie) ===");
        Kosc kosc1 = new Kosc();
        kosc1.wyswietlInformacje();

        System.out.println("\nPodaj wartość oczek dla drugiej kości (liczba od 1 do 6): ");
        int podanaWartosc = scanner.nextInt();

        System.out.println("\n=== TWORZENIE DRUGIEJ KOŚCI (Konstruktor jednoargumentowy) ===");
        Kosc kosc2 = new Kosc(podanaWartosc);
        kosc2.wyswietlInformacje();

        scanner.close();
    }
}